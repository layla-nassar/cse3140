if __name__ == "__main__":

import sys
import os
with open('Q1B.out', 'a') as f:
    f.write(f"{' '.join(sys.argv)}\n")
# VIRUS_MARKER

    pass